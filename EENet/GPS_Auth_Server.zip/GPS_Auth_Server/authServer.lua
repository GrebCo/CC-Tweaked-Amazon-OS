-- GPS-Based Player Authentication Server
-- Trilaterates computer positions from beacon measurements
-- Verifies positions against player detector

---------------------------------------------------------------------
-- Configuration
---------------------------------------------------------------------
local PROTOCOL = "GPSAuth"
local MEASUREMENT_TIMEOUT = 2  -- Seconds to wait for beacon measurements
local REQUEST_EXPIRY = 10000  -- 10 seconds in milliseconds
local POSITION_TOLERANCE = 1  -- Blocks - how close computer must be to player
local MIN_BEACONS = 3  -- Minimum beacons required for trilateration

---------------------------------------------------------------------
-- Load Trilateration Module
---------------------------------------------------------------------
local trilateration = dofile("trilateration.lua")

---------------------------------------------------------------------
-- State
---------------------------------------------------------------------
local pendingRequests = {}  -- {clientID: {measurements: [], replyChannel: number, timestamp: number, timer: number}}
local sessions = {}         -- {clientID: {username: string, timestamp: number}}
local playerDetector = nil
local modem = nil
local timers = {}  -- {timerID: clientID} mapping

---------------------------------------------------------------------
-- Initialization
---------------------------------------------------------------------
local function init()
    -- Find player detector
    playerDetector = peripheral.find("playerDetector")
    if not playerDetector then
        print("[ERROR] No playerDetector peripheral found!")
        print("Please attach an Advanced Peripherals Player Detector.")
        error("PlayerDetector required")
    end
    print("[INFO] Player Detector found: " .. peripheral.getName(playerDetector))

    -- Find and open modem
    modem = peripheral.find("modem")
    if not modem then
        error("No modem found! Please attach a wireless modem.")
    end

    -- Open rednet (NOT hosting - we use DNS for security)
    rednet.open(peripheral.getName(modem))
    print("[INFO] Rednet opened")
    print("[INFO] Listening for beacon measurements on protocol '" .. PROTOCOL .. "'")

    print("")
    print("==============================================")
    print("  GPS Player Authentication Server")
    print("  Protocol: " .. PROTOCOL)
    print("  IMPORTANT: Add this server to DNS_Master.json")
    print("  Computer ID: " .. os.getComputerID())
    print("==============================================")
    print("")
end

---------------------------------------------------------------------
-- Player Detection
---------------------------------------------------------------------
local function findPlayerAtPosition(pos)
    -- Try to get players in range with positions
    local success, players = pcall(function()
        return playerDetector.getPlayersInRange(50)
    end)

    if not success or not players then
        -- Fallback: check if any player is in the tolerance box
        local pos1 = {
            x = pos.x - POSITION_TOLERANCE,
            y = pos.y - POSITION_TOLERANCE,
            z = pos.z - POSITION_TOLERANCE
        }
        local pos2 = {
            x = pos.x + POSITION_TOLERANCE,
            y = pos.y + POSITION_TOLERANCE,
            z = pos.z + POSITION_TOLERANCE
        }

        local hasPlayer = playerDetector.isPlayersInCoords(pos1, pos2)
        if hasPlayer then
            return "Unknown"  -- Player found but can't get name
        else
            return nil
        end
    end

    -- Check each player's position
    for _, player in ipairs(players) do
        if player.x and player.y and player.z and player.name then
            local dx = math.abs(player.x - pos.x)
            local dy = math.abs(player.y - pos.y)
            local dz = math.abs(player.z - pos.z)

            if dx <= POSITION_TOLERANCE and dy <= POSITION_TOLERANCE and dz <= POSITION_TOLERANCE then
                print("[PLAYER MATCH] Found player '" .. player.name .. "' at computed position")
                print("  Player: (" .. player.x .. ", " .. player.y .. ", " .. player.z .. ")")
                print("  Computer: (" .. string.format("%.1f", pos.x) .. ", " .. string.format("%.1f", pos.y) .. ", " .. string.format("%.1f", pos.z) .. ")")
                return player.name
            end
        end
    end

    return nil  -- No player found at position
end

---------------------------------------------------------------------
-- Process Authentication Request
---------------------------------------------------------------------
local function processAuthRequest(clientID)
    local request = pendingRequests[clientID]
    if not request then
        return
    end

    print("")
    print("[PROCESSING] Client ID: " .. clientID)
    print("  Measurements: " .. #request.measurements)

    -- Check minimum beacons
    if #request.measurements < MIN_BEACONS then
        print("  [FAILED] Insufficient beacons (" .. #request.measurements .. " < " .. MIN_BEACONS .. ")")

        -- Send failure response
        modem.open(request.replyChannel)
        modem.transmit(request.replyChannel, 0, {
            type = "auth_response",
            status = "failed",
            reason = "insufficient_beacons"
        })
        modem.close(request.replyChannel)

        pendingRequests[clientID] = nil
        return
    end

    -- Trilaterate position
    local position, status = trilateration.trilaterate(request.measurements)

    if not position then
        print("  [FAILED] Trilateration failed: " .. tostring(status))

        modem.open(request.replyChannel)
        modem.transmit(request.replyChannel, 0, {
            type = "auth_response",
            status = "failed",
            reason = status
        })
        modem.close(request.replyChannel)

        pendingRequests[clientID] = nil
        return
    end

    print("  Computed Position: (" .. string.format("%.1f", position.x) .. ", " .. string.format("%.1f", position.y) .. ", " .. string.format("%.1f", position.z) .. ")")
    if status ~= "success" then
        print("  [WARNING] " .. status)
    end

    -- Find player at position
    local username = findPlayerAtPosition(position)

    if username then
        -- Authentication successful!
        print("  [SUCCESS] Authenticated as: " .. username)

        -- Create session
        sessions[clientID] = {
            username = username,
            timestamp = os.epoch("utc")
        }

        -- Send success response
        modem.open(request.replyChannel)
        modem.transmit(request.replyChannel, 0, {
            type = "auth_response",
            status = "authenticated",
            username = username,
            position = position,
            sessionID = clientID
        })
        modem.close(request.replyChannel)

    else
        -- No player found
        print("  [FAILED] No player found at computed position")

        modem.open(request.replyChannel)
        modem.transmit(request.replyChannel, 0, {
            type = "auth_response",
            status = "failed",
            reason = "no_player_found",
            position = position
        })
        modem.close(request.replyChannel)
    end

    -- Clean up
    pendingRequests[clientID] = nil
end

---------------------------------------------------------------------
-- Handle Beacon Measurement
---------------------------------------------------------------------
local function handleBeaconMeasurement(measurement)
    if type(measurement) ~= "table" or measurement.type ~= "beacon_measurement" then
        return
    end

    local clientID = measurement.clientID
    local replyChannel = measurement.replyChannel
    local beaconID = measurement.beaconID

    print("[MEASUREMENT] Client: " .. clientID .. " | Beacon: " .. beaconID .. " | Distance: " .. string.format("%.2f", measurement.distance))

    -- Initialize request if new
    if not pendingRequests[clientID] then
        pendingRequests[clientID] = {
            measurements = {},
            replyChannel = replyChannel,
            timestamp = os.epoch("utc"),
            timer = nil
        }

        -- Start timer for processing
        local timer = os.startTimer(MEASUREMENT_TIMEOUT)
        pendingRequests[clientID].timer = timer
        timers[timer] = clientID

        print("  [NEW REQUEST] Started " .. MEASUREMENT_TIMEOUT .. "s timer")
    end

    -- Add measurement (avoid duplicates from same beacon)
    local existing = false
    for _, m in ipairs(pendingRequests[clientID].measurements) do
        if m.beaconID == beaconID then
            existing = true
            break
        end
    end

    if not existing then
        table.insert(pendingRequests[clientID].measurements, {
            beaconPos = measurement.beaconPos,
            beaconID = beaconID,
            distance = measurement.distance
        })
    end
end

---------------------------------------------------------------------
-- Cleanup Expired Requests
---------------------------------------------------------------------
local function cleanupExpiredRequests()
    local currentTime = os.epoch("utc")
    local toRemove = {}

    for clientID, request in pairs(pendingRequests) do
        if (currentTime - request.timestamp) > REQUEST_EXPIRY then
            table.insert(toRemove, clientID)
        end
    end

    for _, clientID in ipairs(toRemove) do
        print("[CLEANUP] Expired request from client " .. clientID)
        pendingRequests[clientID] = nil
    end
end

---------------------------------------------------------------------
-- Main Server Loop
---------------------------------------------------------------------
local function main()
    init()

    while true do
        local event, p1, p2 = os.pullEvent()

        if event == "rednet_message" then
            local senderID = p1
            local message = p2
            -- p3 would be protocol, but we know it's PROTOCOL

            handleBeaconMeasurement(message)

        elseif event == "timer" then
            local timerID = p1
            local clientID = timers[timerID]

            if clientID then
                timers[timerID] = nil
                processAuthRequest(clientID)
            end
        end

        -- Periodic cleanup
        if math.random() < 0.1 then  -- 10% chance each loop
            cleanupExpiredRequests()
        end
    end
end

---------------------------------------------------------------------
-- Start Server
---------------------------------------------------------------------
print("Starting GPS Player Authentication Server...")
print("")

main()
