# GPS-Based Player Authentication System

A location-based authentication system for ComputerCraft that verifies computer users by physically triangulating their position and matching it against real player locations.

## Overview

Traditional authentication systems rely on passwords or codes that can be shared or stolen. This system uses **physical location** as the authentication factor - a computer can only be authenticated if a real player is standing at that exact location.

### How It Works (High Level)

1. **Client Request**: Computer broadcasts an authentication request
2. **Beacon Measurement**: Multiple fixed GPS beacons measure the distance to the requesting computer
3. **Trilateration**: Authentication server calculates the computer's 3D position from beacon measurements
4. **Player Verification**: Server checks if a real player is at that computed position (via player detector)
5. **Authentication**: If player found within 1 block → authenticated as that player

**Key Security**: The client never reports its own location - only beacons measure it. This prevents location spoofing in software.

## Features

- **Location-Based Auth**: Computer must be physically at player's location
- **Anti-Spoofing**: Client cannot fake its position
- **Multi-Beacon**: Requires 3+ beacons to agree on location
- **Real-Time**: Uses player detector to verify live player presence
- **DNS Security**: Auth server registered in DNS prevents rogue servers
- **Session Management**: Maintains authenticated sessions by computer ID

## Requirements

### Authentication Server
- ComputerCraft computer (will be auth server)
- Wireless modem
- **Player Detector** peripheral (Advanced Peripherals)

### GPS Beacons (3-4+ recommended)
- ComputerCraft computers at fixed, known locations
- Wireless modems
- Spread 50+ blocks apart in different locations

### Network Infrastructure
- DNS server running (from EENet)
- Rednet network

### Clients
- Any ComputerCraft computer with wireless modem
- Must be within range of beacons (64 blocks default, 384 with ender modems)

## Installation

### 1. Set Up Authentication Server

```lua
wget https://raw.githubusercontent.com/GrebCo/CC-Tweaked-Amazon-OS/refs/heads/main/EENet/GPS_Auth_Server/install.lua install.lua
install
```

**Important**: The installer will display the server's computer ID. You must add this to DNS:

Edit `DNS_Master.json` on your DNS server:
```json
{"id": 100, "protocol": "GPSAuth", "hostname": "gps_auth_server"}
```
(Replace `100` with your actual auth server computer ID)

Restart the DNS server after editing.

### 2. Set Up GPS Beacons (Minimum 3)

On each beacon computer:

```lua
wget https://raw.githubusercontent.com/GrebCo/CC-Tweaked-Amazon-OS/refs/heads/main/EENet/GPS_Auth_Server/beacons/beacon_install.lua beacon_install.lua
beacon_install
```

Then configure each beacon:
1. Use F3 to get exact X, Y, Z coordinates
2. Edit `beacon_config.lua` with position and unique beacon ID
3. Run `beacon.lua` or reboot

See `beacons/README_BEACON.md` for detailed setup guide.

### 3. Beacon Placement Strategy

Place beacons in a spread-out formation around your authentication area:

```
    Beacon 1
        *
       / \
      /   \
     /     \
    *-------*
Beacon 2   Beacon 3

  (Players authenticate
   in center area)
```

- Minimum 3 beacons (4+ for better accuracy)
- 50+ blocks apart
- Not in a straight line
- Different Y-levels helps 3D accuracy

## Usage

### Client-Side Authentication

```lua
-- Open modem and listen for response
local modem = peripheral.find("modem")
modem.open(1001)  -- Reply channel

-- Broadcast auth request
modem.transmit(1000, 1001, {
    type = "auth_request",
    clientID = os.getComputerID(),
    timestamp = os.epoch("utc")
})

-- Wait for response
local timer = os.startTimer(5)
while true do
    local event, p1, p2, p3, p4, p5 = os.pullEvent()

    if event == "modem_message" and p2 == 1001 then
        local message = p4
        if message.type == "auth_response" then
            if message.status == "authenticated" then
                print("Authenticated as: " .. message.username)
                -- Store session, proceed with authenticated actions
            else
                print("Authentication failed: " .. message.reason)
            end
            break
        end
    elseif event == "timer" and p1 == timer then
        print("Authentication timeout")
        break
    end
end
```

### MiniMark/Fizzle Example

```html
<button label:"Authenticate" onClick:DoAuth>
<id:"status">Not authenticated

<script>
@onClick
function DoAuth()
  -- Note: This requires adding modem access to Fizzle sandbox
  local modem = peripheral.find("modem")
  modem.open(1001)

  modem.transmit(1000, 1001, {
    type = "auth_request",
    clientID = os.getComputerID(),
    timestamp = os.epoch("utc")
  })

  document.setElementBodyById("status", "Authenticating...")

  -- Wait for response (would need event handler)
end
</script>
```

## Authentication Flow (Detailed)

### Step 1: Client Broadcasts Request
```lua
-- On channel 1000 (modem broadcast)
{
  type = "auth_request",
  clientID = 42,
  timestamp = 1234567890
}
```

### Step 2: Beacons Measure Distance
- Each beacon receives the broadcast on channel 1000
- ComputerCraft's `modem_message` event provides distance automatically
- Beacon forwards measurement to auth server via rednet:

```lua
-- Via rednet protocol "GPSAuth" to auth server ID (from DNS)
{
  type = "beacon_measurement",
  beaconPos = {x = 100, y = 64, z = 200},
  beaconID = 1,
  clientID = 42,
  replyChannel = 1001,
  distance = 45.3,
  timestamp = 1234567890
}
```

### Step 3: Auth Server Collects Measurements
- Waits 2 seconds after first measurement
- Collects measurements from multiple beacons for same client

### Step 4: Trilateration
- Computes 3D position using beacon positions + distances
- Uses algebraic solution for 3 beacons, least squares for 4+
- Example output: `{x = 123.5, y = 65.2, z = 234.1}`

### Step 5: Player Detection
- Queries player detector: `getPlayersInRange(50)`
- Checks each player's position against computed position
- Match within 1 block tolerance

### Step 6: Response
```lua
-- Success
{
  type = "auth_response",
  status = "authenticated",
  username = "Steve",
  position = {x = 123.5, y = 65.2, z = 234.1},
  sessionID = 42
}

-- Failure
{
  type = "auth_response",
  status = "failed",
  reason = "no_player_found" | "insufficient_beacons" | "trilateration_failed",
  position = {x = 123.5, y = 65.2, z = 234.1}  -- if available
}
```

## Security Model

### 1. No Client Self-Reporting
- Client never sends its own position
- Only beacons measure distance using ComputerCraft's built-in modem distance
- Distance cannot be spoofed by client software

### 2. Multiple Independent Measurements
- Requires 3+ beacons to agree
- Trilateration validates consistency between measurements
- Single compromised beacon cannot fake location

### 3. Physical Verification
- Computed position must match real player location (from player detector)
- Player detector uses actual game state, cannot be spoofed

### 4. DNS-Based Trust
- Auth server ID registered in `DNS_Master.json` (admin-controlled)
- Beacons query DNS to get trusted auth server ID
- Prevents attackers from setting up rogue auth servers via `rednet.host()`
- Requires compromising DNS server to fake auth server

### 5. Session Binding
- Sessions tied to computer ID
- Cannot transfer session to different computer

## Protocol Reference

### Modem Channels
- **1000**: GPS beacon listen channel (client broadcasts here)
- **1001-1999**: Client reply channels (client-specified)

### Rednet Protocols
- **"GPSAuth"**: Beacon → Auth Server measurements
- **"DNS"**: DNS lookups

### DNS Registration
Auth server entry in `DNS_Master.json`:
```json
{"id": 100, "protocol": "GPSAuth", "hostname": "gps_auth_server"}
```

## Configuration

### Auth Server
- `MEASUREMENT_TIMEOUT = 2` - Seconds to wait for beacons
- `POSITION_TOLERANCE = 1` - Blocks tolerance for player match
- `MIN_BEACONS = 3` - Minimum beacons required
- `REQUEST_EXPIRY = 10000` - Milliseconds before request expires

### Beacons
- See `beacon_config.lua` in each beacon
- Must configure exact position and unique ID

## Troubleshooting

### "insufficient_beacons"
- Less than 3 beacons responded
- Check that beacons are running and in range
- Verify beacons have correct auth server hostname in config
- Check DNS registration

### "trilateration_failed"
- Beacon measurements are inconsistent
- Verify beacon positions in `beacon_config.lua` are **exactly** correct
- Check for beacon placement issues (collinear, too close)
- Increase number of beacons for redundancy

### "no_player_found"
- No player detected at computed position
- Player may be too far from computer (>1 block)
- Player detector may be out of range (~50 blocks)
- Check player detector is working: `playerDetector.getPlayersInRange(50)`

### Authentication times out
- Beacons may not be receiving request (out of range)
- Check modem range (64 blocks default, 384 with ender modems)
- Verify beacons are running (check screens)
- Test with closer beacons first

### Inaccurate position
- Beacon positions in config don't match actual positions
- Use F3 to verify exact coordinates of each beacon computer
- Re-configure all beacons with correct positions
- Consider beacon placement (spread out, not collinear)

## Limitations

1. **Range**: Limited by modem range (64 or 384 blocks)
2. **Setup**: Requires physical beacon placement and configuration
3. **Accuracy**: ±1-2 block accuracy typical
4. **Dimension**: Works within single dimension only
5. **Player Detector Range**: ~50 block range
6. **Stationary Beacons**: Beacons must remain at fixed positions

## Advanced Usage

### Check Session Status
Clients can check if they're authenticated:

```lua
local response = net.query("gps_auth_server", "check_session", "GPSAuth")
-- Returns "authenticated:username" or "not_authenticated"
```

(Note: This requires implementing session check in auth server)

### Multiple Auth Areas
Set up multiple auth systems with:
- Different beacon sets
- Different auth servers
- Different DNS hostnames and protocols

### Combining with OTP
Use both GPS and OTP authentication for maximum security:
1. Client authenticates via GPS to prove physical presence
2. Client then uses OTP to prove identity
3. Both must succeed

## Performance

- **Auth Time**: 2-5 seconds typical
- **Beacon Response**: <100ms to measure and forward
- **Trilateration**: <10ms to compute
- **Player Detection**: <50ms to query

## Architecture

```
Client Computer
    ↓ (modem broadcast channel 1000)
GPS Beacons (3-4+)
    ↓ (rednet "GPSAuth" to verified server ID)
Auth Server
    ├─ Trilateration Module (compute position)
    └─ Player Detector (verify player)
    ↓ (modem transmit to reply channel)
Client Computer (authenticated)
```

## Files

```
GPS_Auth_Server/
├── authServer.lua          # Main authentication server
├── trilateration.lua       # 3D trilateration algorithm
├── startup.lua             # Auto-start for auth server
├── install.lua             # Auth server installer
├── README.md               # This file
└── beacons/
    ├── beacon.lua          # GPS beacon program
    ├── beacon_config.lua   # Beacon configuration template
    ├── beacon_install.lua  # Beacon installer
    └── README_BEACON.md    # Beacon setup guide
```

## Future Enhancements

- Session expiration (time-based)
- Auto-calibration of beacon positions via GPS API
- Dynamic beacon registration
- Admin dashboard (view active sessions, beacon status)
- Fallback authentication methods
- Multi-factor auth (GPS + OTP)
- Beacon health monitoring
- Position history/tracking (for audit)

## Related Systems

- **OTP Authentication**: Password-based auth using chatbox (`../Authentication_Server/`)
- **Web Server**: Serve content over EENet (`../WebServer/`)
- **DNS Server**: Service discovery (`../DNSServer/`)
- **EEBrowser**: Client for browsing MiniMark pages (`../Client/`)

## License

Part of the CC-Tweaked-Amazon-OS / EENet project.

## Support

For issues:
1. Check troubleshooting section above
2. Verify all requirements are met
3. Test with minimal setup (3 beacons, one client)
4. Check server and beacon logs for errors
5. Validate beacon positions are correct
