shell.run("authServer.lua")
